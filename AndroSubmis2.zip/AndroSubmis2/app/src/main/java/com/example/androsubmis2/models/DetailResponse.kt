package com.example.androsubmis2.models

data class DetailResponse(
    val error: Boolean? = null,
    val message: String? = null,
    val event: EventModel? = null
)
